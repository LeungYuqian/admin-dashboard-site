# Admin Dashboard Site

獨立的管理後台應用程式，用於管理 Google 表單複製應用。

## 技術棧
- React 19
- Vite
- TypeScript

## 部署
本項目已配置為獨立部署到 Vercel。

## 開發
```bash
npm install
npm run dev
npm run build
```